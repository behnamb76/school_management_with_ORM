package ir.maktabsharif.Repository;

import ir.maktabsharif.model.Teacher;

public interface TeacherRepository extends BaseRepository<Teacher>{
}
