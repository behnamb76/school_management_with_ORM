package ir.maktabsharif.Repository;

import ir.maktabsharif.model.Exam;

public interface ExamRepository extends BaseRepository<Exam> {
}
