package ir.maktabsharif.Repository;

import ir.maktabsharif.model.Course;

public interface CourseRepository extends BaseRepository<Course> {
}
