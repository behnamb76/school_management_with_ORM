package ir.maktabsharif;

import ir.maktabsharif.Repository.CourseRepository;
import ir.maktabsharif.Repository.ExamRepository;
import ir.maktabsharif.Repository.StudentRepository;
import ir.maktabsharif.Repository.TeacherRepository;
import ir.maktabsharif.Repository.impls.CourseRepositoryImpl;
import ir.maktabsharif.Repository.impls.ExamRepositoryImpl;
import ir.maktabsharif.Repository.impls.StudentRepositoryImpl;
import ir.maktabsharif.Repository.impls.TeacherRepositoryImpl;
import ir.maktabsharif.model.Student;
import ir.maktabsharif.model.Teacher;
import ir.maktabsharif.thread.StudentCountThread;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Date;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        StudentRepository studentRepository = new StudentRepositoryImpl();
        TeacherRepository teacherRepository = new TeacherRepositoryImpl();
        CourseRepository courseRepository = new CourseRepositoryImpl();
        ExamRepository examRepository = new ExamRepositoryImpl();

//        Student student  = Student.builder()
//                .firstName("ali")
//                .lastName("ahmadi")
//                .dob(new Date(19970101))
//                .gpu(16.5F)
//                .nationalCode("332").build();
//        studentRepository.add(student);

//        studentRepository.update(student);

//        System.out.println(studentRepository.findById(11L).get());

//        studentRepository.findAll().forEach(System.out::println);

//        studentRepository.delete(1L);


//        Teacher teacher = Teacher.builder()
//                .firstName("ali")
//                .lastName("najafi")
//                .dob(new Date(19930101))
//                .nationalCode("111").build();
//        teacherRepository.add(teacher);

//        teacherRepository.add(teacher);

//        StudentCountThread studentCountThread = new StudentCountThread();
//        Thread thread = new Thread(studentCountThread);
//        thread.start();

    }
}
